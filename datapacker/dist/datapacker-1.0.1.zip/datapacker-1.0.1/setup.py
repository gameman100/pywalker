from distutils.core import setup

setup(
    name='datapacker',
    version='1.0.1',
    author='jinxizeng',
    author_email='gameman100@qq.com',
    url='www.xxx.com',
    description='Game develop utils',
    packages=['datapacker', ],
    )
