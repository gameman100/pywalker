from distutils.core import setup

setup(
    name = 'datapacker',
    version = '1.0.0',
    py_modules = ['datapacker'],
    author = 'Jin',
    author_email = 'gameman100@qq.com',
    url = '',
    description = 'Game develop utils',
    )
